<?php (defined('BASEPATH')) OR exit('No direct script access allowed');
class MY_Model extends CI_Model {
    protected $table_name = '';

    protected $primary_key = 'id';



    public function __construct() {

        parent::__construct();
        $this->load->database();
        $this->load->helper('inflector');
        if (!$this->table_name) {
            $this->table_name = strtolower(get_class($this));
            //$this->table_name = strtolower(plural(get_class($this)));
        }
    }
    public function get($column=array()) {
        return $this->db->get_where($this->table_name, $column)->row();
    }
    public function get_all($fields = '', $where = array(),$where_in=array(), $table = '', $limit = '', $order_by = array(), $group_by = '', $like = array()) {

        $data = array();

        //echo "hi"; die;

        if ($fields != '') {

            $this->db->select($fields);

        }
        if (count($where)) {

            $this->db->where($where);

        }
        if(count($where_in)){
            $this->db->where_in($where_in);
        }


        if ($table != '') {

            $this->table_name = $table;

        }



        if ($limit != '') {

            $this->db->limit($limit);

        }



        if (!empty($order_by)) {

            $this->db->order_by(key($order_by),$order_by[key($order_by)]);

        }



        if ($group_by != '') {

            $this->db->group_by($group_by);

        }
        if (count($like)) {

            $this->db->like($like);

        }



        $Q = $this->db->get($this->table_name);



        if ($Q->num_rows() > 0) {

            foreach ($Q->result_array() as $row) {

                $data[] = $row;

            }

        }



        $Q->free_result();



        return $data;

    }

    public function get_all_by_left_join($join_table = '', $foreign_key = '', $fields = '', $where = array(), $limit = '', $order_by = array(), $group_by = '') {

        $data = array();

        //echo "hi"; die;

        if ($fields != '') {

            $this->db->select($fields);

        }

        $this->db->from($this->table_name);

        if (count($where)) {

            $this->db->where($where);

        }



        if ($join_table != '' && $foreign_key != '') {

            //echo "'".$this->table_name.".".$foreign_key."=".$join_table.".".$this->primary_key."'";die;
            $this->db->join($join_table, "`".$this->table_name."`.`".$foreign_key."`=`".$join_table."`.`".$this->primary_key."`", 'left');

        }



        if ($limit != '') {

            $this->db->limit($limit);

        }



        if (!empty($order_by)) {

            $this->db->order_by(key($order_by),$order_by[key($order_by)]);

        }



        if ($group_by != '') {

            $this->db->group_by($group_by);

        }



        $Q = $this->db->get();



        if ($Q->num_rows() > 0) {

            foreach ($Q->result_array() as $row) {

                $data[] = $row;

            }

        }

        $Q->free_result();

        return $data;

    }


    public function insert($data) {

        //$data['date_created'] = $data['date_updated'] = date('Y-m-d H:i:s');



        $success = $this->db->insert($this->table_name, $data);

        if ($success) {

            return $this->db->insert_id();

        } else {

            return FALSE;

        }

    }



    public function update($data, $column=array()) {
        //$data['date_updated'] = date('Y-m-d H:i:s');
        $this->db->where($column);
        return $this->db->update($this->table_name, $data);
    }



    public function delete($column=array()) {

        $this->db->where($column);

        return $this->db->delete($this->table_name);

    }

}
