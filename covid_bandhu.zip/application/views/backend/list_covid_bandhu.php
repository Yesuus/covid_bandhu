<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="icon" href="<?php echo base_url('assets/backend/')?>images/favicon.ico" type="image/ico" />

    <title>Village Wise Covid Bandhu </title>

    <!--Common Stylesheet -->
    <?php include('layout/stylesheet.php');?>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

        <!-- left sidebar -->
        <?php include('layout/sidebar.php');?>
        <!-- /left sidebar -->

        <!-- top navigation -->
        <?php include('layout/topnav.php');?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3> <small></small></h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title text-center">
                    <h2 style="float: none">Village Wise Covid Bandhu <!-- <small>Users</small> --></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="row">
                      <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <label for="example-text-input" class="col-form-label">Village</label>
                            <select class="form-control mdb-select min-height-225 min-height-40" id="filter_village">
                                <option value="">Select</option>
                                <?php
                                if(sizeof($village_data) > 0) {
                                    foreach($village_data as $vdata) {
                                    ?>
                                    <option value="<?=$vdata['village_name']?>"><?=$vdata['village_name']?></option>
                                    <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <button type="buton" class="btn btn-info rest-buton" id="resetData">Reset</button>
                        </div>
                      </div>
                    </div>
                    <table id="listCovidData" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                            <!-- <th>ID. No.</th> -->
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Village</th>
                            <th>Last Login Date</th>
                        </tr>
                      </thead>
                      <tbody>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include('layout/footer.php');?>
        <!-- /footer content -->
      </div>
    </div>

    <!--Common Script -->
    <?php include('layout/script.php');?>
    <script>
        $(document).ready(function(){
          var dataTable = $('#listCovidData').DataTable({
            "ordering": false,
            "processing": true,
            "serverSide": true,
            "columnDefs": [
              {"className": "text-center", "targets": "_all"}
            ],
            "order": [0, 'desc'],
            "ajax": {
                "url": "<?php echo base_url('sdo/get-covid-bandhu'); ?>",
                "type": "POST",
                'data': function(data){
                  // Read values
                  var filter_village = $('#filter_village').val();
                  // Append to data
                  data.filter_village = filter_village;
              },
              // success : function(res){
              //     console.log(res);
              // },
              // error : function(error){
              //     console.log(error);
              // }
            },
            'columns': [
                // { data: 'id' },
                { data: 'name' },
                { data: 'phone' },
                { data: 'village' },
                { data: 'updated_at' },
            ]
          });
          $('#filter_village').on('change',function(){
              dataTable.draw();
          });
          $('#resetData').on('click',function(){
            $('#filter_village').val('');
            dataTable.draw();
          });
        });
    </script>
</body>
</html>
