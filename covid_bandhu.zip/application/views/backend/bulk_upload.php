<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="icon" href="<?php echo base_url('assets/backend/')?>images/favicon.ico" type="image/ico" />

    <title>Excel Upload </title>

    <!--Common Stylesheet -->
    <?php include('layout/stylesheet.php');?>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

        <!-- left sidebar -->
        <?php include('layout/sidebar.php');?>
        <!-- /left sidebar -->

        <!-- top navigation -->
        <?php include('layout/topnav.php');?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3></h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12"></div>
                <div class="col-md-6 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title text-center">
                        <h2 style="float: none">Excel Upload<small></small></h2>
                        <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                        <br />
                        <form class="form-horizontal form-label-left" action="<?php echo base_url('sdo/insert-bulck-upload'); ?>" method="post" enctype="multipart/form-data" >
                            <?php
                            if($this->session->flashdata('success')){
                            ?>
                            <div class="alert alert-success">
                            <strong>Success!</strong> <?php echo $this->session->flashdata('success');?>
                            </div>
                            <?php
                            }
                            ?>
                            <?php
                            if($this->session->flashdata('error')){
                            ?>
                            <div class="alert alert-danger">
                            <strong>Opps!</strong> <?php echo $this->session->flashdata('error');?>
                            </div>
                            <?php
                            }
                            ?>
                            <div class="form-group" style="margin-bottom: 15px">
                              <label class="control-label col-md-4 col-sm-4 col-xs-12" for="fullname">Upload Excel File <!-- (Max file size 2MB) * --> :</label>
                              <div class="col-md-8 col-sm-8 col-xs-12">
                                <div class="file btn btn-lg btn-primary btn-green btn-round" style="position: relative;overflow: hidden;margin-left: 10px;">
                                    <i class="fa fa-cloud-upload"></i>
                                    <input type="file" name="member_excel_file" id="member_excel_file" style="position: absolute;font-size: 50px;opacity: 0;right: 0;top: 0;" aria-required="true" accept=".xlsx, .xls">
                                </div>
                                <p id="show_file_name" style="margin-top: 15px;"></p>
                              </div>
                            </div>
                            <div class="ln_solid"></div>
                            <div class="form-group">
                            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                                <!-- <button type="button" class="btn btn-primary">Cancel</button> -->
                                <button type="reset" class="btn btn-primary">Reset</button>
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                            </div>

                        </form>
                        </div>
                    </div>
                </div>
              <div class="col-md-3 col-sm-3 col-xs-12"></div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include('layout/footer.php');?>
        <!-- /footer content -->
      </div>
    </div>

    <!--Common Script -->
    <?php include('layout/script.php');?>
    <script>
      $('#member_excel_file').change(function() {
        console.log('file');
        var i = $('#show_file_name').text('');
        var file = $('#member_excel_file')[0].files[0].name;
        console.log(file);
        $('#show_file_name').text(file);
      });
  </script>
  </body>
</html>
