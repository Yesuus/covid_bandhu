<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SDO Login </title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url('')?>assets/backend/vendors/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url('')?>assets/backend/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url('')?>assets/backend/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?php echo base_url('')?>assets/backend/vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url('')?>assets/backend/build/css/custom.min.css" rel="stylesheet">
    <style type="text/css">
      #content form .submit, .login_content form input[type=submit] {
          float: none !important;
          margin-left: 0 !important;
      }
    </style>
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <img src="<?php echo base_url();?>assets/images/Seal_of_West_Bengal.jpg" style="height: 100px">
            <?php
            $attributes = array('class' => '', 'method' => 'POST', 'id' => 'myform');
            echo form_open(base_url('sdo/sdo-login-check'), $attributes);
            ?>
              <h1>SDO Login</h1>
              <?php
              if($this->session->flashdata('error')){
              ?>
              <div class="alert alert-danger">
                <strong>Opps!</strong> <?php echo $this->session->flashdata('error');?>
              </div>
              <?php
              }
              ?>
              <div>
                <input type="text" class="form-control" placeholder="Enter phone" required="" name="phone_no"/>
              </div>
              <div>
                <input type="password" class="form-control" placeholder="Password" required="" name="password"/>
              </div>
              <div>
                <input type="submit" name="submit" value="Log in" class="btn btn-default submit" >
                <!-- <a class="reset_pass" href="#">Lost your password?</a> -->
              </div>

              <div class="clearfix"></div>

              <div class="separator">

                <div class="clearfix"></div>
                <br />
              </div>
            <?php echo form_close();?>
          </section>
        </div>
      </div>
    </div>
  </body>
</html>
