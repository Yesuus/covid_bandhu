<!-- jQuery -->
<script src="<?php echo base_url('assets/backend/')?>vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url('assets/backend/')?>vendors/bootstrap/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/backend/')?>vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="<?php echo base_url('assets/backend/')?>vendors/nprogress/nprogress.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url('assets/backend/')?>vendors/iCheck/icheck.min.js"></script>
<!-- Datatables -->

<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net/js/jquery.dataTables.min.js"></script>

<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/jszip/dist/jszip.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/pdfmake/build/pdfmake.min.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/pdfmake/build/vfs_fonts.js"></script>
<script src="<?php echo base_url('assets/backend/')?>vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo base_url('assets/backend/')?>build/js/custom.min.js"></script>

<!-- toastr -->
<script src="<?php echo base_url('assets/backend/')?>toastr/toastr.min.js"></script>
<script src="<?php echo base_url();?>assets/backend/ckeditor/ckeditor.js"></script>
<!-- <script src="<?php //echo base_url();?>assets/backend/sweetalert/sweet-alert.min.js"></script> -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>