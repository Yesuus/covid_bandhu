<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="icon" href="<?php echo base_url('assets/backend/')?>images/favicon.ico" type="image/ico" />

    <title>Profile </title>

    <!--Common Stylesheet -->
    <?php include('layout/stylesheet.php');?>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

        <!-- left sidebar -->
        <?php include('layout/sidebar.php');?>
        <!-- /left sidebar -->

        <!-- top navigation -->
        <?php include('layout/topnav.php');?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3></h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12"></div>
                <div class="col-md-6 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                        <h2>Update Password<small></small></h2>
                        <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                        <br />
                            <form id="covidProfileForm1" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" style="display: block">
                                <div class="form-group">
                                    <label for="pasword">Enter Current Password:</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Enter current password">
                                </div>
                                <div class="form-group">
                                    <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                                        <!-- <button type="button" class="btn btn-primary">Cancel</button> -->
                                        <button type="reset" class="btn btn-primary">Reset</button>
                                        <button type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                            </form>
                            <form id="covidProfileForm2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" style="display: none">
                                <div class="form-group">
                                    <label for="pasword">New Password:</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter new password">
                                </div>
                                <div class="form-group">
                                    <label for="pasword">Re-Enter Password:</label>
                                    <input type="password" class="form-control" id="con_password" name="con_password" placeholder="Enter password again">
                                </div>
                                <div class="form-group">
                                    <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                                        <!-- <button type="button" class="btn btn-primary">Cancel</button> -->
                                        <button type="reset" class="btn btn-primary">Reset</button>
                                        <button type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
              <div class="col-md-3 col-sm-3 col-xs-12"></div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include('layout/footer.php');?>
        <!-- /footer content -->
      </div>
    </div>

    <!--Common Script -->
    <?php include('layout/script.php');?>
    <script src="<?php echo base_url(); ?>assets/validate/jquery.validate.js"></script>
    <script>
    $(document).ready(function(){
        $("#covidProfileForm1").validate({
            rules: {
                current_password: {
                    required: true
                }
            },
            submitHandler: function() {
                $.ajax({  
                    url:"<?php echo base_url('covid/check-old-password'); ?>",  
                    method:"POST",  
                    data:$('#covidProfileForm1').serialize(),  
                    beforeSend:function(){  
                        //
                    },  
                    success:function(res){  
                        console.log(res);
                        if(res.status == 'success') {
                            $('#covidProfileForm1')[0].reset();
                            $('#covidProfileForm1').css('display', 'none');
                            $('#covidProfileForm2').css('display', 'block');
                        }else {
                            //$('#pageOverlay').css('display', 'none');
                            swal("Opps!", res.msg, "error");
                        }
                    }  
                });  
            }
        });
        $("#covidProfileForm2").validate({
            rules: {
                password: {
                    required: true
                },
                con_password: {
                    required: true,
                    equalTo: '#password'
                }
            },
            submitHandler: function() {
                $.ajax({  
                    url:"<?php echo base_url('covid/save-profile-information'); ?>",  
                    method:"POST",  
                    data:$('#covidProfileForm2').serialize(),  
                    beforeSend:function(){  
                        //
                    },  
                    success:function(res){  
                        console.log(res);
                        if(res.status == 'success') {
                            $('#covidProfileForm2')[0].reset();
                            swal({
                                title: "Wow!",
                                text: res.msg,
                                icon: "success"
                            }).then(function() {
                                window.location.reload();
                            });
                        }else {
                            //$('#pageOverlay').css('display', 'none');
                            swal("Opps!", res.msg, "error");
                        }
                    }  
                });  
            }
        });
    });
  </script>
  </body>
</html>