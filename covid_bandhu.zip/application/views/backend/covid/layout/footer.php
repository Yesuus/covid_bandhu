<footer>

  <div class="pull-right">

  Covid Bandhu

  </div>

  <div class="clearfix"></div>

</footer>