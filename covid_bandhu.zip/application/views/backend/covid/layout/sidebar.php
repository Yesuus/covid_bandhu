<div class="col-md-3 left_col menu_fixed">
  <div class="left_col scroll-view">
    <div class="navbar nav_title" style="border: 0;">
      <div class="text-center" style="padding: 5px;">
        <a href="<?php echo base_url(); ?>">
          <img src="<?php echo base_url(); ?>assets/images/Seal_of_West_Bengal.jpg" style="height: 60px">
        </a>
        <a href="<?php echo base_url('covid/covid-dashboard');?>" class="site_title">
            <span>Covid Bondhu Panel !!!!</span>
        </a>
      </div>
    </div>
    <div class="clearfix"></div>
    <!-- sidebar menu -->
    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
      <div class="menu_section">
        <!-- <h3>General</h3> -->
        <ul class="nav side-menu">
          <li><a href="<?php echo base_url('covid/covid-dashboard'); ?>"><i class="fa fa-home"></i> Dashboard </a></li>
          <!-- <li><a href="<?php //echo base_url('covid/list-member'); ?>"><i class="fa fa-list" aria-hidden="true"></i> List Member </a></li> -->
          <li><a href="<?php echo base_url('covid/profile'); ?>"><i class="fa fa-user" aria-hidden="true"></i> Your Profile </a></li>
          <li><a href="<?php echo base_url('covid/covid-logout'); ?>"><i class="fa fa-power-off" aria-hidden="true"></i> Logout </a></li>
        </ul>
      </div>
    </div>
    <!-- /sidebar menu -->
    <!-- /menu footer buttons -->
    <!-- <div class="sidebar-footer hidden-small">
      <a data-toggle="tooltip" data-placement="top" title="Dashboard" href="<?php //echo base_URL('covid/covid-dashboard'); ?>">
        <i class="fa fa-home" aria-hidden="true"></i>
      </a>
      <a data-toggle="tooltip" data-placement="top" title="Settings">
        <i class="fa fa-cog" aria-hidden="true"></i>
      </a>
      <a data-toggle="tooltip" data-placement="top" title="Web Site" href="<?php //echo base_URL('/'); ?>" target="_balnk">
        <i class="fa fa-eye-slash" aria-hidden="true"></i>
      </a>
      <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php //echo base_URL('covid/covid-logout'); ?>">
        <i class="fa fa-power-off" aria-hidden="true"></i>
      </a>
    </div> -->
    <!-- /menu footer buttons -->
  </div>
</div>



