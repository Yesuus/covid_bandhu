<!-- Bootstrap -->
<link href="<?php echo base_url('')?>assets/backend/vendors/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo base_url('')?>assets/backend/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<!-- NProgress -->
<link href="<?php echo base_url('')?>assets/backend/vendors/nprogress/nprogress.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo base_url('')?>assets/backend/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
<!-- Datatables -->
<link href="<?php echo base_url('')?>assets/backend/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url('')?>assets/backend/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url('')?>assets/backend/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url('')?>assets/backend/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url('')?>assets/backend/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">


<!-- toastr -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/')?>toastr/toastr.min.css">
<link href="<?php echo base_url();?>assets/backend/sweetalert/sweet-alert.css" rel="stylesheet" media="screen">
<link href="<?php echo base_url('assets/backend/')?>build/css/custom.min.css" rel="stylesheet">
<link href="<?php echo base_url('assets/backend/')?>build/css/style.css" rel="stylesheet">

