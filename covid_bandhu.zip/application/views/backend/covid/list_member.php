<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="icon" href="<?php echo base_url('assets/backend/')?>images/favicon.ico" type="image/ico" />

    <title>Dashboard | SDO </title>

    <!--Common Stylesheet -->
    <?php include('layout/stylesheet.php');?>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

        <!-- left sidebar -->
        <?php include('layout/sidebar.php');?>
        <!-- /left sidebar -->

        <!-- top navigation -->
        <?php include('layout/topnav.php');?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3> <small></small></h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>List Member <!-- <small>Users</small> --></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <table id="listMember" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                            <th>Sl. No.</th>
                            <th>Family Head Name</th>
                            <th>Family Head Mob No</th>
                            <th>COVID Bandhu Name </th>
                            <th>Village Name</th>
                            <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include('layout/footer.php');?>
        <!-- /footer content -->
      </div>
    </div>
    <!-- Modal -->
    <div id="questionModal" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Welcome Covid Bondhu</h4>
          </div>
            <div class="modal-body">
              <form id="questionForm" name="questionForm" method="post">
                <div class="row" id="questionFormInput"></div>
                <div class="row">
                  <div class="col-md-12 text-right">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                  </div>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              
            </div>
        </div>

      </div>
    </div>
    <!--Common Script -->
    <?php include('layout/script.php');?>
    <script src="<?php echo base_url(); ?>assets/validate/jquery.validate.js"></script>
    <script>
        $(document).ready(function(){
          //$('#branchesListTable').css('visibility', 'unset');
          $('#listMember').DataTable({
              "processing": true,
              "serverSide": true,
              "order": [0, 'desc'],
              "ajax": {
                  "url": "<?php echo base_url('covid/get-member'); ?>",
                  "type": "POST",
                  // success : function(res){
                  //     console.log(res);
                  // },
                  // error : function(error){
                  //     console.log(error);
                  // }
              },
              'columns': [
                  { data: 'sl_no' },
                  { data: 'family_head_name' },
                  { data: 'family_head_mob_no' },
                  { data: 'covid_name' },
                  { data: 'village_name' },
                  { data: 'action' },
              ]
          });
          $("#questionForm").validate({
            rules: {
              question1: {
                  required: true
              },
              question2: {
                  required: true
              },
              question3: {
                  required: true
              },
              question4: {
                  required: true
              },
              question5: {
                  required: true
              }
            },
            messages: {
              question1: {
                required: "Please chose a answer"
              },
              question2: {
                required: "Please chose a answer"
              },
              question3: {
                required: "Please chose a answer"
              },
              question4: {
                required: "Please chose a answer"
              },
              question5: {
                required: "Please chose a answer"
              }
            },
            errorPlacement: function(error, element) {
                if (element.attr("type") == "radio") {
                    error.insertBefore(element);
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function() {
                $.ajax({  
                    url:"<?php echo base_url('covid/save-question'); ?>",  
                    method:"POST",  
                    data:$('#questionForm').serialize(),  
                    beforeSend:function(){  
                        //$('#pageOverlay').css('display', 'block');
                    },  
                    success:function(res){  
                        console.log(res);
                        if(res.status == 'success') {
                            //$('#pageOverlay').css('display', 'none');
                            $('#questionForm')[0].reset();
                            $('#questionModal').modal('hide');
                            swal({
                                title: "Wow!",
                                text: res.msg,
                                icon: "success"
                            }).then(function() {
                                window.location.reload();
                            });
                        }else {
                            //$('#pageOverlay').css('display', 'none');
                            swal("Opps!", res.msg, "error");
                        }
                    }  
                });  
            }
          });
        });
        function editQuestion(id) {
          // $('#hidden_question_id').val(id);
          // $('#questionModal').modal('show');
          $.ajax({  
            url:"<?php echo base_url('covid/add-question'); ?>",  
            method:"POST",
            data: {id:id},
            beforeSend:function(){  
                //$('#pageOverlay').css('display', 'block');
            },  
            success:function(res){
              //console.log(res);
              //$('#pageOverlay').css('display', 'none');
              $('#questionFormInput').html('');
              $('#questionFormInput').append(res);
              $('#questionModal').modal('show');
            }  
          });
        }
    </script>
</body>
</html>
