<style type="text/css">
    .green-btn{
        width: fit-content;
        background: green;
        color: #FFF;
        padding: 5px 10px;
        float: left;
        margin-right: 10px;
    }
    .orange-btn{
        width: fit-content;
        background: orange;
        color: #FFF;
        padding: 5px 10px;
        float: left;
        margin-right: 10px;
    }
    .red-btn{
        width: fit-content;
        background: red;
        color: #FFF;
        padding: 5px 10px;
        float: left;
        margin-right: 10px;
    }
    .m-bt-15{
        margin-bottom: 15px;
    }
</style>
<!-- <div class="col-md-12 col-sm-12 col-xs-12 text-center">
    <?php //if(!empty($covid_bondhu[0]['name'])) { echo "Mr. ".$covid_bondhu[0]['name']; }?>
</div> -->
<div class="col-md-12 col-sm-12 col-xs-12 text-right">
    Today: <?php echo date('d M Y'); ?>
</div>
<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="question-heading-div">
        <label>
            Name:
            <?php
            if(!empty($covid_member[0]['family_head_name'])) {
                echo $covid_member[0]['family_head_name'];
            }
            ?>
        </label><br/>
        <label>
            Mob:
            <?php
            if(!empty($covid_member[0]['family_head_mob_no'])) {
                echo $covid_member[0]['family_head_mob_no'];
            }
            ?>
        </label><br/>
        <label>
            Global Serial Number:
            <?php
            if(!empty($covid_member[0]['sl_no'])) {
                echo $covid_member[0]['sl_no'];
            }
            ?>
        </label>
    </div>
</div>
<p>&nbsp;</p>
<div class="col-md-12 col-sm-12 col-xs-12">
    <input type="hidden" id="hidden_question_id" name="hidden_question_id" value="<?php if(!empty($member_id)) {echo $member_id;}?>">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 m-bt-15">
            <div class="form-group">
                <label for="exampleInputEmail1">1. সবাই খাবার খেয়েছেন ?</label><br>
                <?php
                $checked1 = 'checked="checked"';
                $checked0 = '';
                $display = 'style="display:none"';
                if(isset($question_data[0]['question1'])) {
                    if($question_data[0]['question1'] == '1') {
                        $checked1 ='checked="checked"';
                    }
                    if($question_data[0]['question1'] == '0') {
                        $checked0 ='checked="checked"';
                        $display = 'style="display:block"';
                    }
                }
                ?>
                <div class="custom-control custom-radio green-btn">
                    <input type="radio" class="custom-control-input" id="question1checked1" name="question1" value="1" <?=$checked1?>>
                    <label class="custom-control-label" for="question1checked1">হ্যাঁ </label>
                </div>
                <div class="custom-control custom-radio red-btn">
                    <input type="radio" class="custom-control-input" id="question1checked0" name="question1" value="0" <?=$checked0?>>
                    <label class="custom-control-label" for="question1checked0">না </label>
                </div>
            </div>

            <div class="form-group comment1Input" id="comment1Input" <?=$display?>>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <label>Add Comment</label>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <textarea class="form-control" name="question1_comment" id="question1_comment"><?php if(!empty($question_data[0]['comment1'])) { echo $question_data[0]['comment1'];}?></textarea>
                    <br/>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-xs-12 m-bt-15">
            <div class="form-group">
                <label for="exampleInputEmail1">2. রেশন ঠিক পাচ্ছেন ?</label><br>
                <?php
                $checked1 = 'checked="checked"';
                $checked0 = '';
                $display = 'style="display:none"';
                if(isset($question_data[0]['question2'])) {
                    if($question_data[0]['question2'] == '1') {
                        $checked1 ='checked="checked"';
                    }
                    if($question_data[0]['question2'] == '0') {
                        $checked0 ='checked="checked"';
                        $display = 'style="display:block"';
                    }
                }
                ?>
                <div class="custom-control custom-radio green-btn">
                    <input type="radio" class="custom-control-input" id="question2checked1" name="question2" value="1" <?=$checked1?>>
                    <label class="custom-control-label" for="question2checked1">হ্যাঁ </label>
                </div>
                <div class="custom-control custom-radio red-btn">
                    <input type="radio" class="custom-control-input" id="question2checked0" name="question2" value="0" <?=$checked0?>>
                    <label class="custom-control-label" for="question2checked0">না </label>
                </div>
            </div>
            <div class="form-group" id="comment2Input" <?=$display?>>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <label>Add Comment</label>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <textarea class="form-control" name="question2_comment" id="question2_comment"><?php if(!empty($question_data[0]['comment2'])) { echo $question_data[0]['comment2'];}?></textarea>
                    <br/>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-xs-12 m-bt-15">
            <div class="form-group">
                <label for="exampleInputEmail1">3. শরীরের কোন সমস্যা ?</label><br>
                <?php
                $checked2 = '';
                $checked1 = '';
                $checked0 = 'checked="checked"';
                $display = 'style="display:none"';
                if(isset($question_data[0]['question3'])) {
                    if($question_data[0]['question3'] == '2') {
                        $checked2 ='checked="checked"';
                        $display = 'style="display:block"';
                    }
                    if($question_data[0]['question3'] == '1') {
                        $checked1 ='checked="checked"';
                        $display = 'style="display:block"';
                    }
                    if($question_data[0]['question3'] == '0') {
                        $checked0 ='checked="checked"';
                    }
                }
                ?>
                <div class="custom-control custom-radio red-btn">
                    <input type="radio" class="custom-control-input" id="question3checked1" name="question3" value="2" <?=$checked1?>>
                    <label class="custom-control-label" for="question3checked1">খুব </label>
                </div>
                <div class="custom-control custom-radio orange-btn">
                    <input type="radio" class="custom-control-input" id="question3checked2" name="question3" value="1" <?=$checked2?>>
                    <label class="custom-control-label" for="question3checked2">মাঝামাঝি  </label>
                </div>
                <div class="custom-control custom-radio green-btn">
                    <input type="radio" class="custom-control-input" id="question3checked0" name="question3" value="0" <?=$checked0?>>
                    <label class="custom-control-label" for="question3checked0">একদম নেই  </label>
                </div>
            </div>
            <div class="form-group" id="comment3Input" <?=$display?>>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <label>Add Comment</label>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <textarea class="form-control" name="question3_comment" id="question3_comment"><?php if(!empty($question_data[0]['comment3'])) { echo $question_data[0]['comment3'];}?></textarea>
                    <br/>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-xs-12 m-bt-15">
            <div class="form-group">
                <label for="exampleInputEmail1">4. মাস্ক পরছেন ?</label><br>
                <?php
                $checked1 = 'checked="checked"';
                $checked0 = '';
                $display = 'style="display:none"';
                if(isset($question_data[0]['question4'])) {
                    if($question_data[0]['question4'] == '1') {
                        $checked1 ='checked="checked"';
                    }
                    if($question_data[0]['question4'] == '0') {
                        $checked0 ='checked="checked"';
                        $display = 'style="display:block"';
                    }
                }
                ?>
                <div class="custom-control custom-radio green-btn">
                    <input type="radio" class="custom-control-input" id="question4checked1" name="question4" value="1" <?=$checked1?>>
                    <label class="custom-control-label" for="question4checked1">হ্যাঁ </label>
                </div>
                <div class="custom-control custom-radio red-btn">
                    <input type="radio" class="custom-control-input" id="question4checked0" name="question4" value="0" <?=$checked0?>>
                    <label class="custom-control-label" for="question4checked0">না </label>
                </div>
            </div>
            <div class="form-group" id="comment4Input" <?=$display?>>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <label>Add Comment</label>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <textarea class="form-control" name="question4_comment" id="question4_comment"><?php if(!empty($question_data[0]['comment4'])) { echo $question_data[0]['comment4'];}?></textarea>
                    <br/>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-xs-12 m-bt-15">
            <div class="form-group">
                <label for="exampleInputEmail1">5. ঠিক মত হাত ধুয়েছেন ?</label><br>
                <?php
                $checked1 = 'checked="checked"';
                $checked0 = '';
                $display = 'style="display:none"';
                if(isset($question_data[0]['question5'])) {
                    if($question_data[0]['question5'] == '1') {
                        $checked1 ='checked="checked"';
                    }
                    if($question_data[0]['question5'] == '0') {
                        $checked0 ='checked="checked"';
                        $display = 'style="display:block"';
                    }
                }
                ?>
                <div class="custom-control custom-radio green-btn">
                    <input type="radio" class="custom-control-input" id="question5checked1" name="question5" value="1" <?=$checked1?>>
                    <label class="custom-control-label" for="question5checked1">হ্যাঁ </label>
                </div>
                <div class="custom-control custom-radio red-btn">
                    <input type="radio" class="custom-control-input" id="question5checked0" name="question5" value="0" <?=$checked0?>>
                    <label class="custom-control-label" for="question5checked0">না </label>
                </div>
            </div>
            <div class="form-group" id="comment5Input" <?=$display?>>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <label>Add Comment</label>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 padding0">
                    <textarea class="form-control" name="question5_comment" id="question5_comment"><?php if(!empty($question_data[0]['comment1'])) { echo $question_data[0]['comment1'];}?></textarea>
                    <br/>
                </div>
            </div>
        </div>
    </div>
</div>