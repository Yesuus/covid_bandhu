<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="icon" href="<?php echo base_url('assets/backend/')?>images/favicon.ico" type="image/ico" />

    <title>Dashboard | COVID Bandhu</title>

    <!--Common Stylesheet -->
    <?php include('layout/stylesheet.php');?>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

        <!-- left sidebar -->
        <?php include('layout/sidebar.php');?>
        <!-- /left sidebar -->

        <!-- top navigation -->
        <?php include('layout/topnav.php');?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row">
            <div style="text-align: center;" class="col-md-12">
              <h2 style="margin-top: 200px;font-size: 40px !important;">Profile</h2>
              <!-- <p style="color: #666;">Current Visitor : <span id="current_visitor" style="color: #FC182D;">0</span></p> -->
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include('layout/footer.php');?>
        <!-- /footer content -->
      </div>
    </div>

    <!--Common Script -->
    <?php include('layout/script.php');?>
    
  </body>
</html>
