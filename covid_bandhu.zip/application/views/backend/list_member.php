<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="icon" href="<?php echo base_url('assets/backend/')?>images/favicon.ico" type="image/ico" />
    <title>Update Covid Bandhu</title>
    <!--Common Stylesheet -->
    <?php include('layout/stylesheet.php');?>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

        <!-- left sidebar -->
        <?php include('layout/sidebar.php');?>
        <!-- /left sidebar -->

        <!-- top navigation -->
        <?php include('layout/topnav.php');?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3> <small></small></h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title text-center">
                    <h2 style="float: none">Update Covid Bandhu  <!-- <small>Users</small> --></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <table id="listMember" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                            <th>Global Serial Number</th>
                            <th>Family Head Name</th>
                            <th>Family Head Mob No</th>
                            <th>Assigned COVID Bandhu </th>
                            <th>COVID Bandhu Mob No</th>
                            <th>Village Name</th>
                        </tr>
                      </thead>
                      <tbody>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include('layout/footer.php');?>
        <!-- /footer content -->
      </div>
    </div>
    <!-- Modal -->
    <div id="assigndCovidModal" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Assigned Covid Bondhu</h4>
          </div>
          <form id="assigndCovidForm" name="assigndCovidForm" method="post">
            <div class="modal-body">
              <div class="row" id="assigndCovidFormInput"></div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save</button>
            </div>
          </form>
        </div>

      </div>
    </div>
    <!--Common Script -->
    <?php include('layout/script.php');?>
    <script src="<?php echo base_url(); ?>assets/validate/jquery.validate.js"></script>
    <script>
        $(document).ready(function(){
          //$('#branchesListTable').css('visibility', 'unset');
          $('#listMember').DataTable({
            "ordering": false,
            "processing": true,
            "serverSide": true,
            "columnDefs": [
              {"className": "text-center", "targets": "_all"}
            ],
            "order": [0, 'desc'],
            "ajax": {
                "url": "<?php echo base_url('sdo/get-member'); ?>",
                "type": "POST",
                // success : function(res){
                //     console.log(res);
                // },
                // error : function(error){
                //     console.log(error);
                // }
            },
            'columns': [
                { data: 'sl_no' },
                { data: 'family_head_name' },
                { data: 'family_head_mob_no' },
                { data: 'covid_name' },
                { data: 'moblie_no' },
                { data: 'village_name' },
            ]
          });
          $("#assigndCovidForm").validate({
            rules: {
              assigned_covid_bhondhu: {
                  required: true
              }
            },
            errorPlacement: function(error, element) {
                if (element.attr("type") == "radio") {
                    error.insertBefore(element);
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function() {
                $.ajax({  
                    url:"<?php echo base_url('sdo/save-assignd-covid-bondhu'); ?>",  
                    method:"POST",  
                    data:$('#assigndCovidForm').serialize(),  
                    beforeSend:function(){  
                        //
                    },  
                    success:function(res){  
                        console.log(res);
                        if(res.status == 'success') {
                            $('#assigndCovidForm')[0].reset();
                            $('#assigndCovidModal').modal('hide');
                            swal({
                                title: "Wow!",
                                text: res.msg,
                                icon: "success"
                            }).then(function() {
                              //console.log("reload");
                              window.location.reload();
                            });
                        }else {
                            swal("Opps!", res.msg, "error");
                        }
                    }  
                });  
            }
          });
        });
        function assigndCovid(id) {
          $.ajax({  
            url:"<?php echo base_url('sdo/assignd-covid-bondhu'); ?>",  
            method:"POST",
            data: {id:id},
            beforeSend:function(){  
                //$('#pageOverlay').css('display', 'block');
            },  
            success:function(res){
              //console.log(res);
              //$('#pageOverlay').css('display', 'none');
              $('#assigndCovidFormInput').html('');
              $('#assigndCovidFormInput').append(res);
              $('#assigndCovidModal').modal('show');
            }  
          });
        }
    </script>
</body>
</html>
