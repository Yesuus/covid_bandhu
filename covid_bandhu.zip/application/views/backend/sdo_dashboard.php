<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="icon" href="<?php echo base_url('assets/backend/')?>images/favicon.ico" type="image/ico" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/backend/jquery-ui.css">
    <title>Dashboard | SDO </title>
    <style>
      @media(min-width: 768px) {
        .dataTables_filter {
            width: 25% !important;
            float: right;
            text-align: right;
        }
    }
    </style>
    <!--Common Stylesheet -->
    <?php include('layout/stylesheet.php');?>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

        <!-- left sidebar -->
        <?php include('layout/sidebar.php');?>
        <!-- /left sidebar -->

        <!-- top navigation -->
        <?php include('layout/topnav.php');?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3> <small></small></h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title text-center">
                    <h2 style="float: none">Welcome to Covid bondhu Monitoring System <!-- <small>Users</small> --></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="row">
                      <div class="col-md-3 col-sm-12">
                        <div class="form-group">
                            <label for="example-text-input" class="col-form-label">Everyone having Food?</label>
                            <select class="form-control mdb-select min-height-225 min-height-40" id="filter_question1">
                                <option value="">Select</option>
                                <option value="1">Yes </option>
                                <option value="0">No </option>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-3 col-sm-12">
                        <div class="form-group">
                            <label for="example-text-input" class="col-form-label">Getting the Ration correctly?</label>
                            <select class="form-control mdb-select min-height-225 min-height-40" id="filter_question2">
                                <option value="">Select</option>
                                <option value="1">Yes</option>
                                <option value="0">No </option>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-3 col-sm-12">
                        <div class="form-group">
                            <label for="example-text-input" class="col-form-label">Any Medical Issue?</label>
                            <select class="form-control mdb-select min-height-225 min-height-40" id="filter_question3">
                                <option value="">Select</option>
                                <option value="2">Severe Symptom </option>
                                <option value="1">Mild Symptom </option>
                                <option value="0">Nothing </option>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-3 col-sm-12">
                        <div class="form-group">
                            <label for="example-text-input" class="col-form-label">Using Mask?</label>
                            <select class="form-control mdb-select min-height-225 min-height-40" id="filter_question4">
                                <option value="">Select</option>
                                <option value="1">Yes</option>
                                <option value="0">No </option>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-3 col-sm-12">
                        <div class="form-group">
                            <label for="example-text-input" class="col-form-label">Washing Hands?</label>
                            <select class="form-control mdb-select min-height-225 min-height-40" id="filter_question5">
                                <option value="">Select</option>
                                <option value="1">Yes </option>
                                <option value="0">No </option>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-3 col-sm-12">
                        <div class="form-group">
                            <label for="example-text-input" class="col-form-label">Village</label>
                            <select class="form-control mdb-select min-height-225 min-height-40" id="filter_village">
                                <option value="">Select</option>
                                <?php
                                if(sizeof($village_data) > 0) {
                                    foreach($village_data as $vdata) {
                                    ?>
                                    <option value="<?=$vdata['village_name']?>"><?=$vdata['village_name']?></option>
                                    <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-3 col-sm-12">
                        <div class="form-group">
                            <label class="col-form-label">Date </label>
                            <input class="form-control form-datepicker" type="text" name="filter_date" id="filter_date" autocomplete="off">
                        </div>
                      </div>
                      <div class="col-md-3 col-sm-12">
                        <div class="form-group">
                            <button type="buton" class="btn btn-info rest-buton" id="resetData">Reset</button>
                        </div>
                      </div>
                    </div>
                    <table id="listReport" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                            <th class="text-center">Global Serial Number</th>
                            <th class="text-center">Family Head Name</th>
                            <th class="text-center">Mobile No</th>
                            <th class="text-center">Assigned COVID Bandhu </th>
                            <th class="text-center">COVID Bandhu Mob</th>
                            <th class="text-center">Village</th>
                            <th class="text-center">Everyone having Food?</th>
                            <th class="text-center">Getting the Ration right?</th>
                            <th class="text-center">Any Medical Issue?</th>
                            <th class="text-center">Using Mask?</th>
                            <th class="text-center">Washing Hands?</th>
                            <th class="text-center">Date</th>
                        </tr>
                      </thead>
                      <tbody>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include('layout/footer.php');?>
        <!-- /footer content -->
      </div>
    </div>

    <!--Common Script -->
    <?php include('layout/script.php');?>
    <script src="<?php echo base_url(); ?>assets/backend/jquery-ui.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.colVis.min.js"></script>
    <!-- <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script> -->
    <script>
    $( ".form-datepicker" ).datepicker({});
    $(document).ready(function(){
      var dataTable = $('#listReport').DataTable({
        dom: 'lBfrtip',
        buttons: [
            'colvis',
            'excelHtml5',
            {
extend: 'pdfHtml5',
orientation: 'landscape',
pageSize: 'LEGAL' }
        ],
        "scrollX": true,
        "ordering": false,
        "processing": true,
        "serverSide": true,
        "columnDefs": [
          {"className": "text-center", "targets": "_all"}
        ],
        "order": [0, 'desc'],
        "ajax": {
            "url": "<?php echo base_url('sdo/list-report'); ?>",
            "type": "POST",
            'data': function(data){
                // Read values
                var filter_question1 = $('#filter_question1').val();
                var filter_question2 = $('#filter_question2').val();
                var filter_question3 = $('#filter_question3').val();
                var filter_question4 = $('#filter_question4').val();
                var filter_question5 = $('#filter_question5').val();
                var filter_village = $('#filter_village').val();
                var filter_date = $('#filter_date').val();
                // Append to data
                data.filter_question1 = filter_question1;
                data.filter_question2 = filter_question2;
                data.filter_question3 = filter_question3;
                data.filter_question4 = filter_question4;
                data.filter_question5 = filter_question5;
                data.filter_village = filter_village;
                data.filter_date = filter_date;
            },
            // success : function(res){
            //     console.log(res);
            // },
            // error : function(error){
            //     console.log(error);
            // }
        },
        'columns': [
            { data: 'sl_no' },
            { data: 'family_head_name' },
            { data: 'family_head_mob_no' },
            { data: 'covid_name' },
            { data: 'covid_mob' },
            { data: 'village_name' },
            { data: 'question1' },
            { data: 'question2' },
            { data: 'question3' },
            { data: 'question4' },
            { data: 'question5' },
            { data: 'date' },
        ]
      });
      $('#filter_question1').on('change',function(){
          dataTable.draw();
      });
      $('#filter_question2').on('change',function(){
          dataTable.draw();
      });
      $('#filter_question3').on('change',function(){
          dataTable.draw();
      });
      $('#filter_question4').on('change',function(){
          dataTable.draw();
      });
      $('#filter_question5').on('change',function(){
          dataTable.draw();
      });
      $('#filter_village').on('change',function(){
          dataTable.draw();
      });
      $('#filter_date').on('change',function(){
          dataTable.draw();
      });
      $('#resetData').on('click',function(){
        $('#filter_question1').val('');
        $('#filter_question2').val('');
        $('#filter_question3').val('');
        $('#filter_question4').val('');
        $('#filter_question4').val('');
        $('#filter_village').val('');
        $('#filter_date').val('');
        dataTable.draw();
      });
    });
    </script>
  </body>
</html>
