<input type="hidden" id="hidden_covid_bondhu" name="hidden_covid_bondhu" value="<?php if(!empty($member_id)) {echo $member_id;}?>">
<div class="form-group">
    <label for="exampleInputEmail1">Assigned Covid Bhondhu</label>
    <select class="form-control" id="assigned_covid_bhondhu" name="assigned_covid_bhondhu">
        <option value="">Select</option>
        <?php
        if(sizeof($covid_bandhu) > 0) {
            foreach($covid_bandhu as $cb_data) {
                $sel = "";
                if($cb_data['id'] == $covid_member[0]['fk_covid_id']) $sel='selected="selected"';
            ?>
            <option value="<?=$cb_data['id']?>" <?=$sel?>><?=$cb_data['name']?></option>
            <?php
            }
        }
        ?>
    </select>
</div>