
    <link href="<?php echo base_url(); ?>assets/frontend/vendor/slick/slick.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/frontend/vendor/animate/animate.min.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/frontend/icons/style.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/frontend/vendor/bootstrap-datetimepicker/bootstrap-datetimepicker.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/frontend/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/frontend/color/color.css" rel="stylesheet">
	<!--Favicon-->
	<link rel="icon" href="images/favicon.png" type="image/x-icon">
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">