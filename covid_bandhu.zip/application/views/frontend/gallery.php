<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta name="description" content="html 5 template, dentist, stomatologist, dental clinic template, medical template, clinic template, surgery clinic theme, plastic surgery template">
	<meta name="author" content="websmirno.site">
	<meta name="format-detection" content="telephone=no">
	<title>Medin - HTML Website Template</title>
	<!--=========================*
                stylesheet
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/stylesheets.php');?>
    <link href="<?php echo base_url(); ?>assets/frontend/vendor/twentytwenty/twentytwenty.css" rel="stylesheet">
</head>

<body class="shop-page">
    <!--=========================*
                Navbar
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/navbar.php');?>

    <!--=========================*
                Quick Links
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/quick_links.php');?>

    <div class="page-content">
        <!--section-->
        <div class="section mt-0">
            <div class="breadcrumbs-wrap">
                <div class="container">
                    <div class="breadcrumbs">
                        <a href="index-2.html">Home</a>
                        <span>Smiles Gallery</span>
                    </div>
                </div>
            </div>
        </div>
        <!--//section-->
        <!--section-->
        <div class="section page-content-first">
            <div class="container">
                <div class="text-center mb-2  mb-md-3 mb-lg-4">
                    <div class="h-sub theme-color">Our Clients Stories</div>
                    <h1>Smiles Gallery</h1>
                    <div class="h-decor"></div>
                </div>
            </div>
            <div class="container">
                <div class="text-center mb-3 mb-md-4 max-900">
                    <p>We love to see our patients smile! Here are some of our best before-and-after pictures,<br>all in one fantastic Smile Gallery</p>
                </div>
                <div class="filters-by-category mb-2 mb-lg-4">
                    <ul class="option-set justify-content-center" data-option-key="filter">
                        <li><a href="#filter" data-option-value="*" class="selected">All</a></li>
                        <li><a href="#filter" data-option-value=".category1">Crowns</a></li>
                        <li><a href="#filter" data-option-value=".category2">Bridges</a></li>
                        <li><a href="#filter" data-option-value=".category3">Dental Implants</a></li>
                        <li><a href="#filter" data-option-value=".category4">Cosmetic Filling</a></li>
                        <li><a href="#filter" data-option-value=".category5">Lumineers</a></li>
                        <li><a href="#filter" data-option-value=".category6">Dentures</a></li>
                        <li><a href="#filter" data-option-value=".category7">Porcelain Veneers</a></li>
                        <li><a href="#filter" data-option-value=".category8">Diamond Polish</a></li>
                    </ul>
                </div>
                <div class="gallery-wrap">
                    <div class="loading-content">
                        <div class="inner-circles-loader"></div>
                    </div>
                    <div class="gallery-smiles gallery-isotope" id="gallery">
                        <div class="gallery-item category2 category7">
                            <div class="twentytwenty-container">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-1-1.jpg" alt=""/>
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-1-2.jpg" alt=""/>
                            </div>
                        </div>
                        <div class="gallery-item category1 category5 category8">
                            <div class="twentytwenty-container">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-2-1.jpg" alt=""/>
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-2-2.jpg" alt=""/>
                            </div>
                        </div>
                        <div class="gallery-item category2 category4 category3">
                            <div class="twentytwenty-container">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-3-1.jpg" alt=""/>
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-3-2.jpg" alt=""/>
                            </div>
                        </div>
                        <div class="gallery-item category4 category8 category6">
                            <div class="twentytwenty-container">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-4-1.jpg" alt=""/>
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-4-2.jpg" alt=""/>
                            </div>
                        </div>
                        <div class="gallery-item category3 category7">
                            <div class="twentytwenty-container">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-5-1.jpg" alt=""/>
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-5-2.jpg" alt=""/>
                            </div>
                        </div>
                        <div class="gallery-item category4 category7 category3">
                            <div class="twentytwenty-container">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-6-1.jpg" alt=""/>
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-6-2.jpg" alt=""/>
                            </div>
                        </div>
                        <div class="gallery-item category1 category8">
                            <div class="twentytwenty-container">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-7-1.jpg" alt=""/>
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-7-2.jpg" alt=""/>
                            </div>
                        </div>
                        <div class="gallery-item category2 category6">
                            <div class="twentytwenty-container">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-8-1.jpg" alt=""/>
                                <img src="<?php echo base_url(); ?>assets/frontend/images/content/gallery/smile-8-2.jpg" alt=""/>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!--//section-->
        <!--section call us-->
        <div class="section mt-5">
            <div class="container">
                <div class="banner-call">
                    <div class="row no-gutters">
                        <div class="col-md-7 d-flex align-items-center">
                            <div class="text-center w-100">
                                <h2>Want the Same <span class="theme-color">Wonderful Smile?</span></h2>
                                <div class="h-decor"></div>
                                <p class="mt-sm-1 mt-lg-4 text-left text-sm-center">We provide advanced, trusted dental care delivered by a dedicated team in our modern practice.</p>
                                <div class="mt-2 mt-lg-4 text-center">
                                    <a href="#" class="banner-call-phone"><i class="icon-telephone"></i>1-800-267-0000</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-lg-5 mt-3 mt-md-0 text-center text-lg-left">
                            <img src="<?php echo base_url(); ?>assets/frontend/images/content/banner-callus-2.html" alt="" class="shift-right">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--section call us-->
    </div>
    <!--=========================*
                Footer
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/footer.php');?>
    
    <!--=========================*
                Scripts
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/scripts.php');?>
    <script src="<?php echo base_url(); ?>assets/frontend/vendor/twentytwenty/jquery.event.move.js"></script>
    <script src="<?php echo base_url(); ?>assets/frontend/vendor/twentytwenty/jquery.twentytwenty.js"></script>
</body>
</html>