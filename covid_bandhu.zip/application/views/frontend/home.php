<!DOCTYPE html>
<html>
<head>
    <title>Covid Bandhu</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <img src="<?php echo base_url();?>assets/images/Seal_of_West_Bengal.jpg" style="height: 150px">
                <h3 style="text-align: center">Welcome To Covid Bandhu</h3>
                <hr>
            </div>
            <div class="col-md-12" style="margin-top: 2vh;text-align: center">
                <a href="<?php echo base_url('sdo-login')?>" class="btn btn-default">SDO Login</a><br><br>
                <p>Or</p>
                <a href="<?php echo base_url('covid-login')?>" class="btn btn-default">COVID Bandhu Login</a>
            </div>
        </div>
    </div>
</body>
</html>