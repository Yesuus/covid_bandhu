<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta name="description" content="html 5 template, dentist, stomatologist, dental clinic template, medical template, clinic template, surgery clinic theme, plastic surgery template">
	<meta name="author" content="websmirno.site">
	<meta name="format-detection" content="telephone=no">
	<title>Contact Us</title>
	<!--=========================*
                stylesheet
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/stylesheets.php');?>
    <!-- <link rel="stylesheet" href="<?php //echo base_url(); ?>assets/frontend/css/style-0.css"> -->
</head>

<body class="shop-page" data-gr-c-s-loaded="true">
    <!--=========================*
                Navbar
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/navbar.php');?>

    <!--=========================*
                Quick Links
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/quick_links.php');?>

    <div class="page-content">
        <!--section-->
        <div class="section mt-0">
            <div class="contact-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d40119.804311386426!2d-97.32055794896301!3d37.64364017354126!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87bae4ec254beb5f%3A0x410df48edd2f5ede!2sGraceMed%20Jardine%20Family%20Clinic!5e0!3m2!1sen!2sua!4v1579853082410!5m2!1sen!2sua" allowfullscreen=""></iframe>		</div>
        </div>
        <!--//section-->
        <!--section-->
        <div class="section mt-0 bg-grey">
            <div class="container">
                <div class="row">
                    <div class="col-md">
                        <div class="title-wrap">
                            <h5>Clinic Location</h5>
                            <div class="h-decor"></div>
                        </div>
                        <ul class="icn-list-lg">
                            <li><i class="icon-placeholder2"></i> DentCo Dental Clinic
                                <br>1560 Holden Street San Diego,
                                <br>CA 92139
                            </li>
                        </ul>
                    </div>
                    <div class="col-md mt-3 mt-md-0">
                        <div class="title-wrap">
                            <h5>Contact Info</h5>
                            <div class="h-decor"></div>
                        </div>
                        <ul class="icn-list-lg">
                            <li><i class="icon-telephone"></i>Phone: <span class="theme-color"><span class="text-nowrap">1-800-267-0000,</span> <span class="text-nowrap">1-800-267-0001</span>
                                    </span>
                                <br> Fax: <span class="theme-color"><span class="text-nowrap">(957) 267-0020</span>
                                    </span>
                            </li>
                            <li><i class="icon-black-envelope"></i><a href="mailto:info@dentco.net">info@dentco.net</a></li>
                        </ul>
                    </div>
                    <div class="col-md mt-3 mt-md-0">
                        <div class="title-wrap">
                            <h5>Working Time</h5>
                            <div class="h-decor"></div>
                        </div>
                        <ul class="icn-list-lg">
                            <li><i class="icon-clock"></i>
                                <div>
                                    <div class="d-flex"><span>Mon-Thu</span><span class="theme-color">08:00 - 20:00</span></div>
                                    <div class="d-flex"><span>Friday</span><span class="theme-color">07:00 - 22:00</span></div>
                                    <div class="d-flex"><span>Saturday</span><span class="theme-color">08:00 - 18:00</span></div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--//section-->
        <!--section-->
        <div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-md col-lg-5">
                        <div class="pr-0 pr-lg-8">
                            <div class="title-wrap">
                                <h2>Get In Touch With Us</h2>
                                <div class="h-decor"></div>
                            </div>
                            <div class="mt-2 mt-lg-4">
                                <p>For general questions, please send us a message and we’ll get right back to you. You can also call us directly to speak with a member of our service team or insurance expert.</p>
                                <p class="p-sm">Fields marked with a * are required.</p>
                            </div>
                            <div class="mt-2 mt-md-5"></div>
                            <h5>Stay Connected</h5>
                            <div class="content-social mt-15">
                                <a href="https://www.facebook.com/" target="blank" class="hovicon"><i class="icon-facebook-logo"></i></a>
                                <a href="https://www.twitter.com/" target="blank" class="hovicon"><i class="icon-twitter-logo"></i></a>
                                <a href="https://plus.google.com/" target="blank" class="hovicon"><i class="icon-google-logo"></i></a>
                                <a href="https://www.instagram.com/" target="blank" class="hovicon"><i class="icon-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md col-lg-6 mt-4 mt-md-0">
                        <form class="contact-form" id="contactForm" method="post" novalidate="novalidate">
                            <div class="successform">
                                <p>Your message was sent successfully!</p>
                            </div>
                            <div class="errorform">
                                <p>Something went wrong, try refreshing and submitting the form again.</p>
                            </div>
                            <div>
                                <input type="text" class="form-control" name="name" placeholder="Your name*">
                            </div>
                            <div class="mt-15">
                                <input type="text" class="form-control" name="email" placeholder="Email*">
                            </div>
                            <div class="mt-15">
                                <input type="text" class="form-control" name="phone" placeholder="Your Phone">
                            </div>
                            <div class="mt-15">
                                <textarea class="form-control" name="message" placeholder="Message"></textarea>
                            </div>
                            <div class="mt-3">
                                <button type="submit" class="btn btn-hover-fill"><i class="icon-right-arrow"></i><span>Send message</span><i class="icon-right-arrow"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--//section-->
    </div>
    <!--=========================*
                Footer
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/footer.php');?>
    <!--=========================*
                Scripts
    *===========================-->
    <?php include(APPPATH.'views/frontend/layout/scripts.php');?>
</body>
</html>