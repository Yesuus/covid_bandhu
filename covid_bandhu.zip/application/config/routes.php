<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'HomeController';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['about-us'] = 'HomeController/about_us';
$route['contact-us'] = 'HomeController/contact_us';
$route['gallery'] = 'HomeController/gallery';


/*=========================*
            SDO Panel
*===========================*/
    /*=========================*
            SDO Login Controller
    *===========================*/
    $route['sdo-login'] = 'sdo/SdoLoginController';
    $route['sdo/sdo-login-check'] = 'sdo/SdoLoginController/sdo_login_check';

    /*=========================*
            SDO Dashboard Controller
    *===========================*/
    $route['sdo/sdo-dashboard'] = 'sdo/SdoDashboardController';
    $route['sdo/excel-upload'] = 'sdo/SdoDashboardController/excel_upload';
    $route['sdo/insert-bulck-upload'] = 'sdo/SdoDashboardController/insert_bulck_upload';
    $route['sdo/list-member'] = 'sdo/SdoDashboardController/list_member';
    $route['sdo/get-member'] = 'sdo/SdoDashboardController/get_member';
    $route['sdo/list-covid-bandhu'] = 'sdo/SdoDashboardController/list_covid_bandhu';
    $route['sdo/get-covid-bandhu'] = 'sdo/SdoDashboardController/get_covid_bandhu';
    $route['sdo/assignd-covid-bondhu'] = 'sdo/SdoDashboardController/assignd_covid_bondhu';
    $route['sdo/save-assignd-covid-bondhu'] = 'sdo/SdoDashboardController/save_assignd_covid_bondhu';
    $route['sdo/list-report'] = 'sdo/SdoDashboardController/list_report';
    $route['sdo/profile'] = 'sdo/SdoDashboardController/profile';
    $route['sdo/save-profile-information'] = 'sdo/SdoDashboardController/save_profile_information';
    $route['sdo/check-old-password'] = 'sdo/SdoDashboardController/check_old_password';
    $route['sdo/sdo-logout'] = 'sdo/SdoDashboardController/sdo_logout';

    /*=========================*
            Covid Login Controller
    *===========================*/
    $route['covid-login'] = 'covid/CovidLoginController';
    $route['covid/covid-login-check'] = 'covid/CovidLoginController/covid_login_check';

    /*=========================*
            COVID Dashboard Controller
    *===========================*/
    $route['covid/covid-dashboard'] = 'covid/CovidDashboardController';
    $route['covid/list-member'] = 'covid/CovidDashboardController/list_member';
    $route['covid/get-member'] = 'covid/CovidDashboardController/get_member';
    $route['covid/add-question'] = 'covid/CovidDashboardController/add_question';
    $route['covid/save-question'] = 'covid/CovidDashboardController/save_question';
    $route['covid/profile'] = 'covid/CovidDashboardController/profile';
    $route['covid/save-profile-information'] = 'covid/CovidDashboardController/save_profile_information';
    $route['covid/check-old-password'] = 'covid/CovidDashboardController/check_old_password';
    $route['covid/covid-logout'] = 'covid/CovidDashboardController/covid_logout';
