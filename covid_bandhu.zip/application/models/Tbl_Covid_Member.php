<?php
(defined('BASEPATH')) OR exit('No direct script access allowed');
class Tbl_Covid_Member extends MY_Model{
	function __construct() {
		parent::__construct();
        $this->load->database();
        // Set table name
        $this->table = array('tbl_covid_member as cm','tbl_covid_bandhu_login as cl');
        // Set orderable column fields
        $this->column_order = array('cm.id', 'cm.fk_covid_id', 'cm.sl_no', 'cm.family_head_name', 'cm.family_head_mob_no', 'cm.phone', 'cm.village_name', 'cl.name');
        // Set searchable column fields
        $this->column_search = array('cm.sl_no', 'cm.family_head_name', 'cm.family_head_mob_no', 'cm.phone', 'cm.village_name', 'cl.name');
        // Set default order
        $this->order = array('cm.id' => 'desc');
    }
    function listMemberData($postData=null) {
		$this->_get_datatables_query($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
		}
		if(!empty($this->session->userdata('covid_id'))){
            $query = $this->db->where('cm.fk_covid_id', $this->session->userdata('covid_id'));
        }
		$query = $this->db->order_by('cm.id','desc');
        $query = $this->db->get();
        return $query->result();
	}
	public function countAll() {
		$this->db->from('tbl_covid_member as cm');
		if(!empty($this->session->userdata('covid_id'))){
            $query = $this->db->where('cm.fk_covid_id', $this->session->userdata('covid_id'));
        }
        return $this->db->count_all_results();
    }
    public function countFiltered($postData) {
		$this->_get_datatables_query($postData);
		if(!empty($this->session->userdata('covid_id'))){
            $query = $this->db->where('cm.fk_covid_id', $this->session->userdata('covid_id'));
        }
        $query = $this->db->get();
        return $query->num_rows();
    }
    private function _get_datatables_query($postData) {
        $this->db->select('cm.*, cl.name, cl.phone as covid_moblie')->from('tbl_covid_member as cm');
        $query = $this->db->join('tbl_covid_bandhu_login as cl', 'cl.id = cm.fk_covid_id', 'left');
        if(!empty($this->session->userdata('covid_id'))){
            $query = $this->db->where('cm.fk_covid_id', $this->session->userdata('covid_id'));
        }
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item) {
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }
                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])) {
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
}