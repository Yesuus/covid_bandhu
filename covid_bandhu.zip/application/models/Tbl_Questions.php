<?php
(defined('BASEPATH')) OR exit('No direct script access allowed');
class Tbl_Questions extends MY_Model{
	function __construct() {
		parent::__construct();
		$this->load->database();
        // Set table name
        $this->table = array('tbl_covid_member as cm','tbl_covid_bandhu_login as cl', 'tbl_questions as q');
        // Set orderable column fields
        $this->column_order = array('q.id', 'q.created_at', 'cm.fk_covid_id', 'cm.sl_no', 'cm.family_head_name', 'cm.family_head_mob_no', 'cm.phone', 'cm.village_name', 'cl.name');
        // Set searchable column fields
        $this->column_search = array('q.created_at', 'cm.sl_no', 'cm.family_head_name', 'cm.family_head_mob_no', 'cm.phone', 'cm.village_name', 'cl.name');
        // Set default order
        $this->order = array('cm.id' => 'desc');
	}
	function listReportData($postData=null) {
		$this->_get_datatables_query($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
		}
		// if(!empty($this->session->userdata('covid_id'))){
        //     $query = $this->db->where('cm.fk_covid_id', $this->session->userdata('covid_id'));
        // }
		$query = $this->db->order_by('q.id','desc');
        $query = $this->db->get();
        return $query->result();
	}
	public function countAll() {
		$this->db->from('tbl_questions as q');
		// if(!empty($this->session->userdata('covid_id'))){
        //     $query = $this->db->where('cm.fk_covid_id', $this->session->userdata('covid_id'));
        // }
        return $this->db->count_all_results();
    }
    public function countFiltered($postData) {
		$this->_get_datatables_query($postData);
		// if(!empty($this->session->userdata('covid_id'))){
        //     $query = $this->db->where('cm.fk_covid_id', $this->session->userdata('covid_id'));
        // }
        $query = $this->db->get();
        return $query->num_rows();
    }
    private function _get_datatables_query($postData) {
		$this->db->select('q.*, cm.sl_no, cm.family_head_name, cm.family_head_mob_no, cm.phone, cm.village_name, cl.name')->from('tbl_questions as q');
		$query = $this->db->join('tbl_covid_member as cm', 'q.covid_member_id = cm.id', 'left');
		$query = $this->db->join('tbl_covid_bandhu_login as cl', 'q.covid_bondhu_id = cl.id', 'left');
		if($this->input->post('filter_question1') != null) {
			$query = $this->db->where('q.question1', $this->input->post('filter_question1'));
		}
		if($this->input->post('filter_question2') != null) {
			$query = $this->db->where('q.question2', $this->input->post('filter_question2'));
		}
		if($this->input->post('filter_question3') != null) {
			$query = $this->db->where('q.question3', $this->input->post('filter_question3'));
		}
		if($this->input->post('filter_question4') != null) {
			$query = $this->db->where('q.question4', $this->input->post('filter_question4'));
		}
		if($this->input->post('filter_question5') != null) {
			$query = $this->db->where('q.question5', $this->input->post('filter_question5'));
		}
		if($this->input->post('filter_village') != null) {
			$query = $this->db->where('cm.village_name', $this->input->post('filter_village'));
        }
        if($this->input->post('filter_date') != null) {
			$query = $this->db->where('DATE_FORMAT(q.created_at, "%Y-%m-%d")=', date('Y-m-d', strtotime($this->input->post('filter_date'))));
		}
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item) {
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }
                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])) {
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
}