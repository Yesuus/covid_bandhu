<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CovidDashboardController extends CI_Controller {
	public function __construct()
    {
    	parent::__construct();
        $this->load->helper('url');    
        $this->load->library('session');
		$this->load->model(array('Tbl_Sdo_Login', 'Tbl_Covid_Bandhu_Login', 'Tbl_Covid_Member', 'Tbl_Questions'));
		$this->load->library('excel');
        if(empty($this->session->userdata('covid_id'))){
        	redirect('covid-login');
        }
    }
	public function index() {
		$data['covid_bondhu'] = $this->Tbl_Covid_Bandhu_Login->get_all('', array('id' => $this->session->userdata('covid_id')));
		$data['list_member'] = $this->Tbl_Covid_Member->get_all('', array('fk_covid_id' => $this->session->userdata('covid_id')));
		$this->load->view('backend/covid/covid_dashboard', $data);
	}
	public function bulck_upload() {
		$this->load->view('backend/bulck_upload');
	}
	public function insert_bulck_upload() {
		//echo $_FILES["member_excel_file"]["name"]; exit();
		if(!empty($_FILES["member_excel_file"]["name"])) {
			$path = $_FILES["member_excel_file"]["tmp_name"];
			$object = PHPExcel_IOFactory::load($path);
			$i = 1;
			$sheetData = $object->getActiveSheet()->toArray(null,true,true,true);
			//echo count($sheetData);
			foreach($object->getWorksheetIterator() as $worksheet) {
				$highestRow = $worksheet->getHighestRow();
				$count_row = $highestRow;
				//echo "count_row-1 ".$highestRow;
				$highestColumn = $worksheet->getHighestColumn();
				for($row=2; $row<=$highestRow; $row++) {
					$sl_no = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
					$family_head_name = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
					$family_head_mob_no = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
					$covid_name = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
					$phone = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
					$village_name = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
					$fk_covid_id = "";
					$covidArrayData = array('name' => $covid_name, 'phone' => $phone, 'password' => md5('123'), 'created_date' => date('Y-m-d H:i:s'), 'updated_date' => date('Y-m-d H:i:s'));
					$select_covid_data = $this->Tbl_Covid_Bandhu_Login->get_all('', array('name' => $covid_name));
					if(sizeof($select_covid_data) > 0) {
						$fk_covid_id = $select_covid_data[0]['id'];
					}else {
						$insert_covid_data = $this->Tbl_Covid_Bandhu_Login->insert($covidArrayData);
						if($insert_covid_data) {
							$fk_covid_id = $this->db->insert_id();
						}else {
							$fk_covid_id = "";
						}
					}
					$covidMemberArrayData = array('sl_no' => $sl_no, 'family_head_name' => $family_head_name, 'family_head_mob_no' => $family_head_mob_no, 'fk_covid_id' => $fk_covid_id, 'village_name' => $village_name, 'created_date' => date('Y-m-d H:i:s'), 'updated_date' => date('Y-m-d H:i:s'));
					$insert_covid_member_data = $this->Tbl_Covid_Member->insert($covidMemberArrayData);
					$i++;
				}
			}
			if(count($sheetData) == $i) {
				$this->session->set_flashdata('success', "Insert done.");
				return redirect('sdo/bulck-upload');
			}else {
				$this->session->set_flashdata('error', "Insert faild. Something is wrong please try again.");
				return redirect('sdo/bulck-upload');
			}
		}else {
			$this->session->set_flashdata('error', "Insert faild. Please select a excel file.");
			return redirect('sdo/bulck-upload');
		}
	}
	public function list_member() {
		$this->load->view('backend/covid/list_member');
	}
	public function get_member() {
	    $data = $row = array();
        // Fetch member's records
        $memData = $this->Tbl_Covid_Member->listMemberData($_POST);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
            $action = '<button type="button" class="btn btn-rounded btn-fixed-w btn-outline-info mb-3" onclick="editQuestion('.$member->id.')"><i class="fa fa-pencil-square-o"></i></button>';
            $data[] = array('sl_no' => $member->sl_no, 'family_head_name' => $member->family_head_name, 'family_head_mob_no' => $member->family_head_mob_no, 'covid_name' => $member->name, 'village_name' => $member->village_name, 'action' => $action);
        }
        $output = array(
            "draw" => intval($_POST['draw']),
			"iTotalRecords" => $this->Tbl_Covid_Member->countAll(),
			"iTotalDisplayRecords" => $this->Tbl_Covid_Member->countFiltered($_POST),
			"aaData" => $data
        );
        // Output to JSON format
        echo json_encode($output);
	}
	public function add_question() {
		$data['covid_bondhu'] = $this->Tbl_Covid_Bandhu_Login->get_all('', array('id' => $this->session->userdata('covid_id')));
		$data['covid_member'] = $this->Tbl_Covid_Member->get_all('', array('id' => $this->input->post('id')));
		$data['question_data'] = $this->Tbl_Questions->get_all('', array('covid_member_id' => $this->input->post('id'), 'DATE_FORMAT(created_at,"%Y-%m-%d")' => date('Y-m-d')));
		$data['member_id'] = $this->input->post('id');
		return $this->load->view('backend/covid/add_question', $data);
	}
	public function save_question() {
		$returnArray = [];
		if(!empty($this->session->userdata('covid_id'))){
			$select_data = $this->Tbl_Questions->get_all('', array('covid_member_id' => $this->input->post('hidden_question_id'), 'DATE_FORMAT(created_at,"%Y-%m-%d")' => date('Y-m-d')));
			if(sizeof($select_data) > 0) {
				$arrayData = array('question1' => $this->input->post('question1'), 'question2' => $this->input->post('question2'), 'question3' => $this->input->post('question3'), 'question4' => $this->input->post('question4'), 'question5' => $this->input->post('question5'), 'comment1' => $this->input->post('question1_comment'), 'comment2' => $this->input->post('question2_comment'), 'comment3' => $this->input->post('question3_comment'), 'comment4' => $this->input->post('question4_comment'), 'comment5' => $this->input->post('question5_comment'), 'updated_at' => date('Y-m-d H:i:s'));
				$update_data = $this->Tbl_Questions->update($arrayData, array('covid_member_id' => $this->input->post('hidden_question_id')));
				if($update_data) {
					$returnArray = array('status' => 'success', 'msg' => "Update success");
				}else {
					$returnArray = array('status' => 'success', 'msg' => "Update faild");
				}
			}else {
				$arrayData = array('question1' => $this->input->post('question1'), 'question2' => $this->input->post('question2'), 'question3' => $this->input->post('question3'), 'question4' => $this->input->post('question4'), 'question5' => $this->input->post('question5'),'covid_member_id' => $this->input->post('hidden_question_id'), 'covid_bondhu_id' => $this->session->userdata('covid_id'), 'comment1' => $this->input->post('question1_comment'), 'comment2' => $this->input->post('question2_comment'), 'comment3' => $this->input->post('question3_comment'), 'comment4' => $this->input->post('question4_comment'), 'comment5' => $this->input->post('question5_comment'), 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s'));
				$save_data = $this->Tbl_Questions->insert($arrayData);
				if($save_data) {
					$returnArray = array('status' => 'success', 'msg' => "Insert success");
				}else {
					$returnArray = array('status' => 'success', 'msg' => "Insert faild");
				}
			}
        }else {
			redirect('covid-login');
		}
		header("Content-type:application/json");
		echo json_encode($returnArray);
	}
	public function profile() {
		$this->load->view('backend/covid/covid_profile');
	}
	public function check_old_password() {
		$returnData = [];
		$select_data = $this->Tbl_Covid_Bandhu_Login->get_all('', array('id' => $this->session->userdata('covid_id'), 'password' => md5($this->input->post('current_password'))));
		if(sizeof($select_data) > 0) {
			$returnData = array('status' => 'success', 'msg' => "Password match.");
		}else {
			$returnData = array('status' => 'error', 'msg' => "Password not match, please enter right password.");
		}
		header("Content-type:application/json");
		echo json_encode($returnData);
	}
	public function save_profile_information() {
		$returnData = [];
		$select_data = $this->Tbl_Covid_Bandhu_Login->get_all('password', array('id' => $this->session->userdata('covid_id')));
		if(sizeof($select_data) > 0) {
			if($select_data[0]['password'] == md5($this->input->post('password'))) {
				$returnData = array('status' => 'error', 'msg' => "Enter password match your current password, please enter new password.");
			}else {
				$arrayData = array('password' => md5($this->input->post('password')));
				$update_data = $this->Tbl_Covid_Bandhu_Login->update($arrayData, array('id' => $this->session->userdata('covid_id')));
				if($update_data) {
					$returnData = array('status' => 'success', 'msg' => "Password update successful.");
				}else {
					$returnData = array('status' => 'error', 'msg' => "Password update faild.");
				}
			}
		}else {
			$returnData = array('status' => 'error', 'msg' => "Something is wrong, pease try again.");
		}
		header("Content-type:application/json");
		echo json_encode($returnData);
	}
	/*=========================*
            Logout
    *===========================*/
	public function covid_logout(){
		$this->session->unset_userdata('covid_id');
		$this->session->sess_destroy();
		redirect('/');
	}
}
