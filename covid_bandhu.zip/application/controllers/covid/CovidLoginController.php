<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CovidLoginController extends CI_Controller {
	public function __construct() {
    	parent::__construct();
        $this->load->helper('url');    
        $this->load->library('session');
        $this->load->model('Tbl_Covid_Bandhu_Login');
        if(!empty($this->session->userdata('covid_id'))){
        	redirect('covid/covid-dashboard');
        }
    }
	public function index() {
		$this->load->view('backend/covid/covid_login');
	}
	public function covid_login_check() {
		$username=$this->input->post('username');
		$password = md5($this->input->post('password'));
		$select_data = $this->Tbl_Covid_Bandhu_Login->get_all('',array('phone' => $username, 'password' => $password));
		if(sizeof($select_data)>0){
			$update_data = $this->Tbl_Covid_Bandhu_Login->update(array('updated_date' => date('Y-m-d H:i:s')), array('id' => $select_data[0]['id']));
			if($update_data) {
				$this->session->set_userdata('covid_id',$select_data[0]['id']);
				redirect('covid/covid-dashboard');
			}else {
				$this->session->set_flashdata("error","Something is wrong, please try again.");
				redirect('covid-login');
			}
		}else{
			$this->session->set_flashdata("error","Login record not match.");
			redirect('covid-login');
		}
	}
}
