<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProfileController extends CI_Controller {
	public function __construct()
    {
    	parent::__construct();
        $this->load->helper('url');    
        $this->load->library('session');
		$this->load->model(array('Tbl_Covid_Bandhu_Login'));
        if(empty($this->session->userdata('covid_id'))){
        	redirect('covid-login');
        }
    }
    public function index(){
        $data['user_data'] = $this->Tbl_Covid_Bandhu_Login->get(array('id'=>$this->session->userdata('covid_id')));
        //print_r($data);
        $this->load->view('backend/covid/profile', $data);
    }
}