<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HomeController extends CI_Controller {
	public function __construct()
    {
    	parent::__construct();
        $this->load->helper('url');
		$this->load->library(array('session'));
        $this->load->model(array()); 
	}
	/*=========================*
            Home
	*===========================*/
	public function index() {
		$this->load->view('frontend/home');
	}
	/*=========================*
            About Us
	*===========================*/
	public function about_us(){
		$this->load->view('frontend/about_us');
	}
	/*=========================*
            Contact Us
	*===========================*/
	public function contact_us(){
		$this->load->view('frontend/contact_us');
	}
	/*=========================*
            Gallery
	*===========================*/
	public function gallery(){
		$this->load->view('frontend/gallery');
	}
	
}
