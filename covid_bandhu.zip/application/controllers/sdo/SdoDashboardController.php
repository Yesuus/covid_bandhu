<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SdoDashboardController extends CI_Controller {
	public function __construct()
    {
    	parent::__construct();
        $this->load->helper('url');    
        $this->load->library('session');
		$this->load->model(array('Tbl_Sdo_Login', 'Tbl_Covid_Bandhu_Login', 'Tbl_Covid_Member', 'Tbl_Questions'));
		$this->load->library('excel');
        if(empty($this->session->userdata('sdo_id'))){
        	redirect('sdo-login');
        }
    }
	public function index() {
		$data['village_data'] = $this->Tbl_Covid_Member->get_all('village_name', array(), array(), '', '', array(), 'village_name');
		$this->load->view('backend/sdo_dashboard', $data);
	}
	public function list_report() {
		$data = $row = array();
        // Fetch member's records
        $memData = $this->Tbl_Questions->listReportData($_POST);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
			$question1 = "No";
			if($member->question1 == '1') {
				$question1 = "Yes";
			}
			$question2 = "No";
			if($member->question2 == '1') {
				$question2 = "Yes";
			}
			$question3 = "Nothing";
			if($member->question3 == '1') {
				$question3 = "Mild Symptom";
			}
			if($member->question3 == '2') {
				$question3 = "Severe Symptom";
			}
			$question4 = "No";
			if($member->question4 == '1') {
				$question4 = "Yes";
			}
			$question5 = "No";
			if($member->question5 == '1') {
				$question5 = "Yes";
			}
            $data[] = array('sl_no' => $member->sl_no, 'family_head_name' => $member->family_head_name, 'family_head_mob_no' => $member->family_head_mob_no, 'covid_name' => $member->name, 'covid_mob' => $member->phone, 'village_name' => $member->village_name, 'question1' => $question1, 'question2' => $question2, 'question3' => $question3, 'question4' => $question4, 'question5' => $question5, 'date' => date('M, d-Y', strtotime($member->created_at)));
        }
        $output = array(
			"draw" => intval($_POST['draw']),
			'page'=>($_POST['start']/$_POST['length'])+1,
            'totalPage'=>ceil($this->Tbl_Questions->countFiltered($_POST)/$_POST['length']),
			"iTotalRecords" => $this->Tbl_Questions->countAll(),
			"iTotalDisplayRecords" => $this->Tbl_Questions->countFiltered($_POST),
			"aaData" => $data
        );
        // Output to JSON format
        echo json_encode($output);
	}
	public function excel_upload() {
		$this->load->view('backend/bulk_upload');
	}
	public function insert_bulck_upload() {
		//echo $_FILES["member_excel_file"]["name"]; exit();
		if(!empty($_FILES["member_excel_file"]["name"])) {
			$path = $_FILES["member_excel_file"]["tmp_name"];
			$object = PHPExcel_IOFactory::load($path);
			$i = 1;
			$sheetData = $object->getActiveSheet()->toArray(null,true,true,true);
			//echo count($sheetData);
			foreach($object->getWorksheetIterator() as $worksheet) {
				$highestRow = $worksheet->getHighestRow();
				$count_row = $highestRow;
				//echo "count_row-1 ".$highestRow;
				$highestColumn = $worksheet->getHighestColumn();
				for($row=2; $row<=$highestRow; $row++) {
					$sl_no = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
					$family_head_name = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
					$family_head_mob_no = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
					$covid_name = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
					$phone = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
					$village_name = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
					$fk_covid_id = "";
					$covidArrayData = array('name' => $covid_name, 'phone' => $phone, 'password' => md5('123'), 'created_date' => date('Y-m-d H:i:s'), 'updated_date' => date('Y-m-d H:i:s'));
					$select_covid_data = $this->Tbl_Covid_Bandhu_Login->get_all('', array('name' => $covid_name));
					if(sizeof($select_covid_data) > 0) {
						$fk_covid_id = $select_covid_data[0]['id'];
					}else {
						$insert_covid_data = $this->Tbl_Covid_Bandhu_Login->insert($covidArrayData);
						if($insert_covid_data) {
							$fk_covid_id = $this->db->insert_id();
						}else {
							$fk_covid_id = "";
						}
					}
					$covidMemberArrayData = array('sl_no' => $sl_no, 'family_head_name' => $family_head_name, 'family_head_mob_no' => $family_head_mob_no, 'fk_covid_id' => $fk_covid_id, 'village_name' => $village_name, 'created_date' => date('Y-m-d H:i:s'), 'updated_date' => date('Y-m-d H:i:s'));
					$insert_covid_member_data = $this->Tbl_Covid_Member->insert($covidMemberArrayData);
					$i++;
				}
			}
			if(count($sheetData) == $i) {
				$this->session->set_flashdata('success', "Insert done.");
				return redirect('sdo/excel-upload');
			}else {
				$this->session->set_flashdata('error', "Insert faild. Something is wrong please try again.");
				return redirect('sdo/excel-upload');
			}
		}else {
			$this->session->set_flashdata('error', "Insert faild. Please select a excel file.");
			return redirect('sdo/excel-upload');
		}
	}
	public function list_member() {
		$this->load->view('backend/list_member');
	}
	public function get_member() {
	    $data = $row = array();
        // Fetch member's records
        $memData = $this->Tbl_Covid_Member->listMemberData($_POST);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
			$action = '<button type="button" class="btn btn-rounded btn-fixed-w btn-outline-info mb-3" onclick="assigndCovid('.$member->id.')"><i class="fa fa-pencil-square-o"></i></button>';
			$moblie_no = '<a href="tel:'.$member->covid_moblie.'">'.$member->covid_moblie.'</a>';
            $data[] = array('sl_no' => $member->sl_no, 'family_head_name' => $member->family_head_name, 'family_head_mob_no' => $member->family_head_mob_no, 'covid_name' => $member->name." ".$action, 'moblie_no' => $moblie_no, 'village_name' => $member->village_name);
        }
        $output = array(
			"draw" => intval($_POST['draw']),
			'page'=>($_POST['start']/$_POST['length'])+1,
            'totalPage'=>ceil($this->Tbl_Covid_Member->countFiltered($_POST)/$_POST['length']),
			"iTotalRecords" => $this->Tbl_Covid_Member->countAll(),
			"iTotalDisplayRecords" => $this->Tbl_Covid_Member->countFiltered($_POST),
			"aaData" => $data
        );
        // Output to JSON format
        echo json_encode($output);
    }
    public function list_covid_bandhu(){
		$data['village_data'] = $this->Tbl_Covid_Member->get_all('village_name', array(), array(), '', '', array(), 'village_name');
    	$this->load->view('backend/list_covid_bandhu', $data);
    }
    public function get_covid_bandhu(){
    	$data = $row = array();
        // Fetch member's records
        $memData = $this->Tbl_Covid_Bandhu_Login->listCovidData($_POST);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
            //$action = '<button type="button" class="btn btn-rounded btn-fixed-w btn-outline-info mb-3" onclick="editQuestion('.$member->member_id.')"><i class="fa fa-pencil-square-o"></i></button>';
            $data[] = array('id' => $member->id, 'name' => $member->name, 'phone' => $member->phone, 'village' => $member->village_name, 'created_at' => $member->created_date, 'updated_at' => $member->updated_date);
        }
        $output = array(
			"draw" => intval($_POST['draw']),
			'page'=>($_POST['start']/$_POST['length'])+1,
            'totalPage'=>ceil($this->Tbl_Covid_Bandhu_Login->countFiltered($_POST)/$_POST['length']),
			"iTotalRecords" => $this->Tbl_Covid_Bandhu_Login->countAll(),
			"iTotalDisplayRecords" => $this->Tbl_Covid_Bandhu_Login->countFiltered($_POST),
			"aaData" => $data
        );
        // Output to JSON format
        echo json_encode($output);
	}
	public function assignd_covid_bondhu() {
		$data['covid_bandhu'] = $this->Tbl_Covid_Bandhu_Login->get_all('', array(), array(), '', '', array('id' => 'DESC'));
		$data['covid_member'] = $this->Tbl_Covid_Member->get_all('fk_covid_id', array('id' => $this->input->post('id')));
		$data['member_id'] = $this->input->post('id');
		return $this->load->view('backend/assignd_covid_bondhu', $data);
	}
	public function save_assignd_covid_bondhu() {
		$returnArray = [];
		$arrayData = array('fk_covid_id' => $this->input->post('assigned_covid_bhondhu'));
		$update_data = $this->Tbl_Covid_Member->update($arrayData, array('id' => $this->input->post('hidden_covid_bondhu')));
		if($update_data) {
			$returnArray = array('status' => 'success', 'msg' => "Update success");
		}else {
			$returnArray = array('status' => 'success', 'msg' => "Update faild");
		}
		header("Content-type:application/json");
		echo json_encode($returnArray);
	}
	public function profile() {
		$this->load->view('backend/profile');
	}
	public function check_old_password() {
		$returnData = [];
		$select_data = $this->Tbl_Sdo_Login->get_all('', array('id' => $this->session->userdata('sdo_id'), 'password' => md5($this->input->post('current_password'))));
		if(sizeof($select_data) > 0) {
			$returnData = array('status' => 'success', 'msg' => "Password match.");
		}else {
			$returnData = array('status' => 'error', 'msg' => "Password not match, please enter right password.");
		}
		header("Content-type:application/json");
		echo json_encode($returnData);
	}
	public function save_profile_information() {
		$returnData = [];
		$select_data = $this->Tbl_Sdo_Login->get_all('password', array('id' => $this->session->userdata('sdo_id')));
		if(sizeof($select_data) > 0) {
			if($select_data[0]['password'] == md5($this->input->post('password'))) {
				$returnData = array('status' => 'error', 'msg' => "Enter password match your current password, please enter new password.");
			}else {
				$arrayData = array('password' => md5($this->input->post('password')));
				$update_data = $this->Tbl_Sdo_Login->update($arrayData, array('id' => $this->session->userdata('sdo_id')));
				if($update_data) {
					$returnData = array('status' => 'success', 'msg' => "Password update successful.");
				}else {
					$returnData = array('status' => 'error', 'msg' => "Password update faild.");
				}
			}
		}else {
			$returnData = array('status' => 'error', 'msg' => "Something is wrong, pease try again.");
		}
		header("Content-type:application/json");
		echo json_encode($returnData);
	}
	/*=========================*
            Logout
    *===========================*/
	public function sdo_logout(){
		$this->session->unset_userdata('sdo_id');
		$this->session->sess_destroy();
		redirect('/');
	}
}
