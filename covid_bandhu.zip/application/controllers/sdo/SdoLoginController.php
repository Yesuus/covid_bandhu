<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SdoLoginController extends CI_Controller {
	public function __construct() {
    	parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
        $this->load->model('Tbl_Sdo_Login');
        if(!empty($this->session->userdata('sdo_id'))){
        	redirect('sdo/sdo-dashboard');
        }
    }
	public function index() {
		$this->load->view('backend/sdo_login');
	}
	public function sdo_login_check() {
		$password = md5($this->input->post('password'));
		$phn = $this->input->post('phone_no');
		$select_data = $this->Tbl_Sdo_Login->get_all('',array('phone' => $phn, 'password' => $password));
		if(sizeof($select_data)>0){
			$this->session->set_userdata('sdo_id',$select_data[0]['id']);
			redirect('sdo/sdo-dashboard');
		}else{
			$this->session->set_flashdata("error","Login record not match.");
			redirect('sdo-login');
		}
	}
}
